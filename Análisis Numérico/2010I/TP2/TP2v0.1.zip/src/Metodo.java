import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.*;

public class Metodo implements Constantes{

	double h, t0, x0, v0;
	ArrayList<Double> x = new ArrayList<Double>();
	ArrayList<Double> v = new ArrayList<Double>();
	ArrayList<Double> energia = new ArrayList<Double>();
	BufferedWriter out;


	public Metodo (){
	try {
		FileWriter fstream = new FileWriter("out.txt");
		out = new BufferedWriter(fstream);
	}
	catch (Exception e){}
	}

	public double f1(double t, double x, double y){
		return y;
	}

	public double f2(double t, double x, double y){
		return ( (a/m)*x - (b/m)*Math.pow(x,3) );
	}

	public double resolver(){
		throw new RuntimeException();
	}

	private double potencial(double x){
		
		return ( ((0.25)*b*Math.pow(x, 4) ) - ( (0.5)*a*Math.pow(x,2)) );
	}
	
	public double energia(double x, double y){
		return ((0.5)*m*Math.pow(x,2) + this.potencial(x));
	}

	
	
	public void imprimirEnergiasFinalMenosInicial(){
		Double en_inicial, en_final;
//		int contador = 0;
//		Iterator<Double> it = this.energia.iterator();

		en_inicial = energia.get(0);
		en_final = energia.get(energia.size() - 1);

		System.out.println ("Energ�a final: "+en_final);
		System.out.println ("Energ�a inicial: "+en_inicial);
		System.out.println ("Resta: "+(en_final-en_inicial));
		System.out.println ("-----------------------");

//		while (it.hasNext()){
//			en_inicial = itei.next();
//			en_final = itef.next();
//			
//			if (contador < 3) System.out.println ("h= "+1);
//			if (contador >= 3 && contador <6) System.out.println ("h= "+0.1);
//			if (contador >= 6) System.out.println ("h= "+0.01);
//
//			if (contador == 0 || contador == 3 || contador == 6) System.out.println ("x=0.5\ny=0");
//			if (contador == 1 || contador == 4 || contador == 7) System.out.println ("x=1\ny=0");
//			if (contador == 2 || contador == 5 || contador == 8) System.out.println ("x=1.5\ny=0");
//			
//			System.out.println ("Energ�a final: "+en_final);
//			System.out.println ("Energ�a inicial: "+en_inicial);
//			System.out.println ("Resta: "+(en_final-en_inicial));
//			System.out.println ("-----------------------");
//			
//			contador++;
//		}
	}
	
	public void imprimir(ArrayList<Double> vector){
		
		Double xn;
		int contador = 0;
		Iterator<Double> itx = vector.iterator();

		while (itx.hasNext()){
			xn = itx.next();
			System.out.println(/*"x("+contador+") = "+*/xn);
	        try { out.write(xn+"\n"); } catch (Exception e){}
			contador++;
		}
		
	}

	public void graficar(){
	}

}
