
public class RungeKuttaOrden2 extends Metodo {

	public RungeKuttaOrden2 (double h, double t, double x, double v){
		this.h = h;
		this.t0 = t;
		this.x0 = x;
		this.v0 = v;
	}

	public double resolver(){
		
		double xn=0, vn=0, tn=0, xn_1=0, vn_1=0;
		double k11, k12, k21, k22;

		int n=0;
		
		x.clear();
		v.clear();
		
		x.add(x0);
		v.add(v0);

		tn = t0+n*h;
		double en = this.energia(x0,v0);
		this.energia.add(en);

		while (tn<T_LIMITE){

			xn = x.get(n);
			vn = v.get(n);
			
			k11 = h*f1(tn,xn,vn);
			k21 = h*f2(tn,xn,vn);
			k12 = h*f1(tn+h,xn+k11,vn+k21);
			k22 = h*f2(tn+h,xn+k11,vn+k21);

//			k11 = h*vn;
//			k21 = h*((a/m)*xn - (b/m)*Math.pow(xn,3));
//			k12 = h*(vn+k21);
//			k22 = h*( (a/m)*(xn+k11) - (b/m)*(Math.pow((xn+k11),3)) );
			
			xn_1 = xn+(0.5)*(k11+k12);
			vn_1 = vn+(0.5)*(k21+k22);
			en = this.energia(xn_1,vn_1);
			
			this.x.add(xn_1);
			this.v.add(vn_1);
			this.energia.add(en);

			n++;
			tn = t0+n*h;
		}
			
//		System.out.println("Posiciones");
//		this.imprimir(x);
//		System.out.println("Velocidades");
//		this.imprimir(v);
//		System.out.println("Energy");
//		this.imprimir(energia);

		
	    try {
	        out.write("Posiciones\n");
			this.imprimir(x);
	        out.write("\nVelocidades\n");
			this.imprimir(v);
	        out.write("\nEnergy\n");
			this.imprimir(energia);
	        out.close();
	    }
	    catch (Exception e){}

	    return (xn_1);
	}
}
