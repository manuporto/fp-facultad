
public class Euler extends Metodo{

	public Euler (double h, double t, double x, double v){
		this.h = h;
		this.t0 = t;
		this.x0 = x;
		this.v0 = v;
	}

	public double resolver(){
		
		double xn=0, vn=0, tn=0;
		double xn_1=0, vn_1=0;
		int n=0;

		x.clear();
		v.clear();
		
		x.add(x0);
		v.add(v0);
		
		tn = t0+n*h;

		double en = this.energia(x0,v0);
		this.energia.add(en);
		
		while (tn<T_LIMITE){

			xn = x.get(n);
			vn = v.get(n);

			xn_1 = xn + h*f1(tn,xn,vn);
			vn_1 = vn + h*f2(tn,xn,vn);
			en = this.energia(xn_1,vn_1);
			
//			xn_1 = xn+h*vn;  // Separar las cuentas por el error de redondeo
//			vn_1 = vn + h*( (a/m)*xn - (b/m)*Math.pow(xn,3) );  // Separar las cuentas por el error de redondeo
			
			this.x.add(xn_1);
			this.v.add(vn_1);
			this.energia.add(en);
		

			n++;
			tn = t0+n*h;
		}

//		System.out.println("Posiciones");
//		this.imprimir(x);
//		System.out.println("Velocidades");
//		this.imprimir(v);
//		System.out.println("Energy");
//		this.imprimir(energia);

		
	    try {
	        out.write("Posiciones\n");
			this.imprimir(x);
	        out.write("\nVelocidades\n");
			this.imprimir(v);
	        out.write("\nEnergy\n");
			this.imprimir(energia);
	        out.close();
	    }
	    catch (Exception e){}
		
		
		return (xn_1);
	}
	
}
