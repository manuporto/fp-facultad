
public class RungeKuttaOrden4 extends Metodo {

	public RungeKuttaOrden4 (double h, double t, double x, double v){
		this.h = h;
		this.t0 = t;
		this.x0 = x;
		this.v0 = v;
	}
	
	public double resolver(){
		
		double xn=0, vn=0, tn=0, xn_1=0, vn_1=0;
		double k11, k12, k13, k14, k21, k22, k23, k24;

		int n=0;
		
		x.clear();
		v.clear();
		
		x.add(x0);
		v.add(v0);

		tn = t0+n*h;
		double en = this.energia(x0,v0);
		this.energia.add(en);

		while (tn<T_LIMITE){

			xn = x.get(n);
			vn = v.get(n);
			
			k11 = h*f1(tn,xn,vn);
			k21 = h*f2(tn,xn,vn);
			
			k12 = h*f1(tn+(0.5)*h,xn+(0.5)*k11,vn+(0.5)*k21);
			k22 = h*f2(tn+(0.5)*h,xn+(0.5)*k11,vn+(0.5)*k21);
			
			k13 = h*f1(tn+(0.5)*h,xn+(0.5)*k12,vn+(0.5)*k22);
			k23 = h*f2(tn+(0.5)*h,xn+(0.5)*k12,vn+(0.5)*k22);
			
			k14 = h*f1(tn+h,xn+k13,vn+k23);
			k24 = h*f2(tn+h,xn+k13,vn+k23);

//			k11 = h*vn;
//			k21 = h*((a/m)*xn - (b/m)*Math.pow(xn,3));
//
//			k12 = h*(vn+(0.5)*k21);
//			k22 = h*( (a/m)*(xn+(0.5)*k11) - (b/m)*(Math.pow((xn+(0.5)*k11),3)) );
//
//			k13 = h*(vn+(0.5)*k22);
//			k23 = h*( (a/m)*(xn+(0.5)*k12) - (b/m)*Math.pow((xn+(0.5)*k12),3));
//				
//			k14 = h*(vn+k23);
//			k24 = h*( (a/m)*(xn+k13) - (b/m)*Math.pow((xn+k13),3));
			
			xn_1 = xn+(0.16667)*(k11+2*k12+2*k13+k14);
			vn_1 = vn+(0.16667)*(k21+2*k22+2*k23+k24);
			en = this.energia(xn_1,vn_1);
			
			this.x.add(xn_1);
			this.v.add(vn_1);
			this.energia.add(en);

			n++;
			tn = t0+n*h;
		}

//		System.out.println("Posiciones");
//		this.imprimir(x);
//		System.out.println("Velocidades");
//		this.imprimir(v);
//		System.out.println("Energy");
//		this.imprimir(energia);

		
	    try {
	        out.write("Posiciones\n");
			this.imprimir(x);
	        out.write("\nVelocidades\n");
			this.imprimir(v);
	        out.write("\nEnergy\n");
			this.imprimir(energia);
	        out.close();
	    }
	    catch (Exception e){}

	    
	    return (xn_1);
	}
}
