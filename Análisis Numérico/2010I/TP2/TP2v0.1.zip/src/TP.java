public class TP {

	public static void imprimirAux (double h, double t, double x, double y, Metodo euler, Metodo RK2, Metodo RK4){

//		System.out.println("x= "+x+"\ny= "+y+"\nh= "+h);
//		System.out.println("        Euler: "+euler.resolver(h,t,x,y));
//		System.out.println("Runge Kutta 2: "+RK2.resolver(h,t,x,y));
//		System.out.println("Runge Kutta 4: "+RK4.resolver(h,t,x,y));
//		System.out.println("------------------");
		
	}
	public static void imprimir (double h, Metodo euler, Metodo RK2, Metodo RK4){

		double t = 0;
		double x,y;


		x = 0.5; y = 0;
		imprimirAux (h,t,x,y,euler,RK2,RK4);

		x = 1; y = 0;
		imprimirAux (h,t,x,y,euler,RK2,RK4);

		x = 1.5; y = 0;
		imprimirAux (h,t,x,y,euler,RK2,RK4);

	}
	
	public static void main(String[] args) {

		// Metodo Eulerij es el m�todo Euler para el caso i, usando hj
		double t = 0;
		double x,y,h;
		
		h = 1;    x= 0.5; y=0; Metodo euler11 = new Euler(h,t,x,y); Metodo RK211 = new RungeKuttaOrden2 (h,t,x,y);  Metodo RK411 = new RungeKuttaOrden4 (h,t,x,y); 
		h = 0.1;  x= 0.5; y=0; Metodo euler12 = new Euler(h,t,x,y); Metodo RK212 = new RungeKuttaOrden2 (h,t,x,y);  Metodo RK412 = new RungeKuttaOrden4 (h,t,x,y); 
		h = 0.01; x= 0.5; y=0; Metodo euler13 = new Euler(h,t,x,y); Metodo RK213 = new RungeKuttaOrden2 (h,t,x,y);  Metodo RK413 = new RungeKuttaOrden4 (h,t,x,y); 
		h = 1;    x= 1.0; y=0; Metodo euler21 = new Euler(h,t,x,y); Metodo RK221 = new RungeKuttaOrden2 (h,t,x,y);  Metodo RK421 = new RungeKuttaOrden4 (h,t,x,y); 
		h = 0.1;  x= 1.0; y=0; Metodo euler22 = new Euler(h,t,x,y); Metodo RK222 = new RungeKuttaOrden2 (h,t,x,y);  Metodo RK422 = new RungeKuttaOrden4 (h,t,x,y); 
		h = 0.01; x= 1.0; y=0; Metodo euler23 = new Euler(h,t,x,y); Metodo RK223 = new RungeKuttaOrden2 (h,t,x,y);  Metodo RK423 = new RungeKuttaOrden4 (h,t,x,y); 
		h = 1;    x= 1.5; y=0; Metodo euler31 = new Euler(h,t,x,y); Metodo RK231 = new RungeKuttaOrden2 (h,t,x,y);  Metodo RK431 = new RungeKuttaOrden4 (h,t,x,y); 
		h = 0.1;  x= 1.5; y=0; Metodo euler32 = new Euler(h,t,x,y); Metodo RK232 = new RungeKuttaOrden2 (h,t,x,y);  Metodo RK432 = new RungeKuttaOrden4 (h,t,x,y); 
		h = 0.01; x= 1.5; y=0; Metodo euler33 = new Euler(h,t,x,y); Metodo RK233 = new RungeKuttaOrden2 (h,t,x,y);  Metodo RK433 = new RungeKuttaOrden4 (h,t,x,y); 

		/*
		euler11.resolver(); RK211.resolver(); RK411.resolver();
		euler12.resolver();*/ RK212.resolver(); /*RK412.resolver();
		euler13.resolver(); RK213.resolver(); RK413.resolver();
		euler21.resolver(); RK221.resolver(); RK421.resolver();
		euler22.resolver(); RK222.resolver(); RK422.resolver();
		euler23.resolver(); RK223.resolver(); RK423.resolver();
		euler31.resolver(); RK231.resolver(); RK431.resolver();
		euler32.resolver(); RK232.resolver(); RK432.resolver();
		euler33.resolver(); RK233.resolver(); RK433.resolver();
		*/


//		Metodo euler = new Euler();
//		Metodo RK2 = new RungeKuttaOrden2();
//		Metodo RK4 = new RungeKuttaOrden4();
//
//		double h;
//
//		System.out.println("Punto 1");
//		System.out.println("-------\n");
//		
//		h = 1;    imprimir(h, euler, RK2, RK4);
//		h = 0.1;  imprimir(h, euler, RK2, RK4);
//		h = 0.01; imprimir(h, euler, RK2, RK4);
//
//		System.out.println("Punto 2");
//		System.out.println("-------\n");
//		System.out.println("Euler"); euler.imprimirEnergias();
//		System.out.println("Runge-Kutta 2"); RK2.imprimirEnergias();
//		System.out.println("Runge-Kutta 4"); RK4.imprimirEnergias();
//		
	}

}
