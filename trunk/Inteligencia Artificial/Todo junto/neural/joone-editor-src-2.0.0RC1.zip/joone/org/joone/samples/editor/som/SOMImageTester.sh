#!/bin/bash
java -cp SOMImageTester.jar org.joone.samples.editor.som.SOMImageTester