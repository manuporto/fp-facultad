
public interface Constantes {

	public static final double a = 1;
	public static final double b = 1;
	public static final double m = 1;
	public static final double T_LIMITE = 20;
	


}
