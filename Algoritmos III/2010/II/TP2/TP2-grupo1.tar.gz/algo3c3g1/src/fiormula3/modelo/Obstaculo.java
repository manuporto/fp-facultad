package fiormula3.modelo;

public abstract class Obstaculo {
}