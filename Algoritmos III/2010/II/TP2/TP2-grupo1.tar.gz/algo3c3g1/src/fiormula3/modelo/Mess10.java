package fiormula3.modelo;

public class Mess10 extends Ruedas {
}
