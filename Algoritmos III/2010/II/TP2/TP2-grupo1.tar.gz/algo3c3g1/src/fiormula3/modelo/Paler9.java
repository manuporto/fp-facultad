package fiormula3.modelo;

public class Paler9 extends Ruedas {
}