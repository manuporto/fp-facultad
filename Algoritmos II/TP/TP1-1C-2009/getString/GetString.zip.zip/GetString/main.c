#include "getString.h"

int main(int argc, char* argv[])
{
    char* mensaje= NULL;
    FILE* archivo;
    int errorCode;

    archivo = fopen("prueba.txt","rt");
    while (!feof(archivo))
    {
        errorCode = getString(&mensaje, archivo);
        if(errorCode == RES_OK)
            printf("El mensaje de prueba era: %s\n",mensaje);
        else
        {
            fclose(archivo);
            return errorCode;
        }
    }
    fclose(archivo);
    free(mensaje);
    return RES_OK;
}
